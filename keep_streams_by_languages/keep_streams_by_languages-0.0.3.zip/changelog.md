**<span style="color:#56adda">0.0.3</span>**
- Fixed bug where subtitle streams would be set to 'default' when they shouldn't be.
- Removed creation of .unmanic files in filesystem.
  
**<span style="color:#56adda">0.0.1</span>**
- Based on keep_stream_by_language v0.1.4 by Josh5/Yajendrag
- Based on Remove Streams by Language v0.0.5
