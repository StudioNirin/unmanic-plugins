# Keep audio/subtitle streams by languages

plugin for [Unmanic](https://github.com/Unmanic)
