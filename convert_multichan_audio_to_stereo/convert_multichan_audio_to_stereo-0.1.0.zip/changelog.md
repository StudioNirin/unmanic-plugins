**<span style="color:#56adda">0.1.0</span>**
- Fixed error with encoding non-aac tracks to aac.
- Fixed sample rate to 48khz for all audio tracks encoded by this plugin
- All features finally work as they should... so bumped it up to 1.0 in celebration!

**<span style="color:#56adda">0.0.9</span>**
- Fixing error where it would add stereo tracks when they already exist.
- Altering default position in stacks to 1 (recommend removal of extra language tracks etc is done first). 

**<span style="color:#56adda">0.0.7</span>**
- Fixed 'Stereo as default track' option.
- Removed option to order tracks by language. 

**<span style="color:#56adda">0.0.4</span>**
- Fixing the 'Stereo as default track' option.

**<span style="color:#56adda">0.0.3</span>**
- Added labels to new Stereo tracks.

**<span style="color:#56adda">0.0.2</span>**
- Updated documentation.

**<span style="color:#56adda">0.0.1</span>**
- initial release
- based on add_extra_stereo_audio
- based on convert_multichannel_audio_to_2_channel by Yajendrag
- fixes issues with subtitle default settings
- fixes issues with audio track ordering
