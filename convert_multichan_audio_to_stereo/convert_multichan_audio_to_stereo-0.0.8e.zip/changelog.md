**<span style="color:#56adda">0.0.8</span>**
- Fixing error where it would add stereo tracks when they already exist.

**<span style="color:#56adda">0.0.7</span>**
- Fixed 'Stereo as default track' option.
- Removed option to order tracks by language. 

**<span style="color:#56adda">0.0.4</span>**
- Fixing the 'Stereo as default track' option.

**<span style="color:#56adda">0.0.3</span>**
- Added labels to new Stereo tracks.

**<span style="color:#56adda">0.0.2</span>**
- Updated documentation.

**<span style="color:#56adda">0.0.1</span>**
- initial release
- based on add_extra_stereo_audio
- based on convert_multichannel_audio_to_2_channel by Yajendrag
- fixes issues with subtitle default settings
- fixes issues with audio track ordering
