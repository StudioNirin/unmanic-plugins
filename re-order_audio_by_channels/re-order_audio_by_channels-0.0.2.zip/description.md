
---

##### Links:

- [Support](https://unmanic.app/discord)
---

##### Documentation:

This plugin will automatically sort audio streams in descending order of channels. 
So 7.1 -> 5.1 -> Stereo -> Mono. 
